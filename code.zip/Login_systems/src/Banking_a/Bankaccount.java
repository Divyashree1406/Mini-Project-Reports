package Banking_a;
import java.util.*;
  class Bankaccount 
	{
	int balance;
	int previous1;
	String customername;
	int customerid;
	Bankaccount()
	{
	customername="ABC";
	customerid= 10001;
	}
	void print()
	{
	System.out.println("customer name : "+customername);
	System.out.println("customer ID : "+customerid);
	}
	void interest()
	{
		Scanner ob = new Scanner(System.in);
		System.out.println("The interest rate provided is 7.5");
		double monthlyInterestRate = 7.5/1200;
		System.out.println("Enter the number of years");
		int numberOfYears = ob.nextInt();
		System.out.println("enter the loan amount");
		double loanAmount = ob.nextDouble();
		double monthlyPayment= loanAmount*monthlyInterestRate/(1-1/Math.pow(1+monthlyInterestRate,numberOfYears*12));
	    double totalPayment = monthlyPayment* numberOfYears*12;
	    System.out.println("The monthy payment is Rs "+(int)(monthlyPayment*100/100.0));
	    System.out.println("The total Payment is Rs "+(int)(totalPayment*100/100.0));
	}



	}
	
