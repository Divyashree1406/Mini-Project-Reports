package Banking_a;

import java.util.Scanner;

public class Previous extends Bankaccount{
	void deposit(int amount)
	{
	if(amount!=0)
	{
	balance=balance+amount;
	previous1=amount;
	}
	}

	void withdraw(int amount)
	{
	if(amount!=0)
	{
	balance=balance-amount;
	previous1=-amount;
	}
	}
	void previoustransaction()
	{
	if(previous1>0)
	{
	System.out.println("Deposited : "+previous1);
	}
	else if(previous1<0)
	{
	System.out.println("Withdrawn : "+ Math.abs(previous1));
	}
	else
	{
	System.out.println("no transaction occured");
	}
	}




		void showmenu()
		{
		Scanner sc= new Scanner(System.in);
		System.out.println("\n");
		System.out.println("A. check balance");
		System.out.println("B. deposit");
		System.out.println("C. withdraw");
		System.out.println("D. previous transaction");
		System.out.println("E. Loan Payment");
		System.out.println("F.Exit");
		char option;
		do
		{
		System.out.println("enter an option : ");
		option=sc.next().charAt(0);
		System.out.println("\n");
		switch(option)
		{
		case 'A': 
	                  System.out.println("Balance= "+balance);
		          break;
		case 'B': System.out.println("enter an amount to deposit");
			  int amount= sc.nextInt();		 
			  deposit(amount);
			  break;
		case 'C': System.out.println("enter an amount to withdraw");
			  int amount2=sc.nextInt();
			  withdraw(amount2);
			  break;
		case 'D': previoustransaction();
	                  break;
		case 'E': interest();
		          break;
		case 'F': System.out.println("-------------------------------------------------------------------------------");
			  break;
		default : System.out.println("invalid option");
			  break;
		}
		}
		while(option!='F');
		System.out.println("Thank you for using our services");
		}
		


		public static void main(String[] args)
		{
		Previous abc = new Previous();
		abc.print();
		abc.showmenu();
		}
	}





