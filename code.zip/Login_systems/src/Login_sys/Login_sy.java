package Login_sys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JTextField;

import Banking_a.Previous;

import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login_sy {

	private JFrame frame;
	private JTextField txtUsername;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_sy window = new Login_sy();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login_sy() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(300, 300, 600, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblPassword = new JLabel("PASSWORD");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPassword.setBounds(52, 167, 118, 25);
		frame.getContentPane().add(lblPassword);
		
		JLabel lblUsername = new JLabel("USERNAME");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblUsername.setBounds(52, 98, 137, 33);
		frame.getContentPane().add(lblUsername);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(254, 98, 202, 29);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Password = txtPassword.getText();
				String Username = txtUsername.getText();
				
				if(Password.contains("pass") && Username.contains("user")) {
					txtPassword.setText(null);
					txtUsername.setText(null);
					
			Previous info = new Previous();
			Previous.main(null);
		
			
					
				}
				else
				{
					JOptionPane.showMessageDialog(null,"Invalid Details","Login Error!", JOptionPane.ERROR_MESSAGE );
					txtPassword.setText(null);
					txtUsername.setText(null);
				}
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnLogin.setBounds(125, 239, 118, 33);
		frame.getContentPane().add(btnLogin);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtUsername.setText(null);
				txtPassword.setText(null);
			
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnReset.setBounds(365, 239, 126, 33);
		frame.getContentPane().add(btnReset);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(254, 167, 202, 25);
		frame.getContentPane().add(txtPassword);
		
		JLabel frmLoginSystems = new JLabel("LOGIN TO CONTINUE...");
		frmLoginSystems.setFont(new Font("Tahoma", Font.BOLD, 22));
		frmLoginSystems.setBounds(153, 27, 266, 33);
		frame.getContentPane().add(frmLoginSystems);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(30, 210, 504, 2);
		frame.getContentPane().add(separator);
	}
}
