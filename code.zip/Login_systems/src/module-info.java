module Login_systems {
	exports Login_sys;

	requires java.desktop;
}